//1
let fruit = 10;
let tkg = 50;
let total = parseInt(fruit) * parseInt(tkg);
if (total >= 500) {
  dis = 500 * 0.9;
}
document.write("打9折" + dis);
//2
let fruit1 = 20;
let tkg2 = 50;
let total1 = parseInt(fruit1) * parseInt(tkg2);
if (total1 >= 500 && total1 < 999) {
  dis2 = 500 * 0.9;
} else if (total1 >= 1000) {
  dis2 = 1000 * 0.7;
}

document.write("<br>" + "打7折" + dis2);

//3

let sum = 0;
let sum1 = 0;
let sum2 = 0;
for (let i = 0; i <= 10; i++) {
  sum += i;
}
document.write("<br>" + "總和:" + sum);

for (let j = 0; j <= 10; j += 2) {
  sum1 += j;
}

document.write("<br>" + "偶數和:" + sum1);

for (let a = 1; a <= 10; a += 2) {
  sum2 += a;
}

document.write("<br>" + "基數和:" + sum2);

//4

let orange = 20;
let tkg3 = 50;
let rank = 3;
let total4;
switch (rank) {
  case 1:
    if (tkg3 < 40) {
      total4 = parseInt(tkg3) * 30;
      document.write("<br>" + "總價:" + total4);
    } else if (tkg3 > 40 && tkg3 < 99) {
      total4 = parseInt(tkg3) * 25;
      document.write("<br>" + "總價:" + total4);
    } else if (tkg >= 100) {
      total4 = parseInt(tkg3) * 20;
      document.write("<br>" + "總價:" + total4);
    }
    break;
  case 2:
    if (tkg3 < 40) {
      total4 = parseInt(tkg3) * 25;
      document.write("<br>" + "總價:" + total4);
    } else if (tkg3 > 40 && tkg3 < 99) {
      total4 = parseInt(tkg3) * 20;
      document.write("<br>" + "總價:" + total4);
    } else if (tkg >= 100) {
      total4 = parseInt(tkg3) * 15;
      document.write("<br>" + "總價:" + total4);
    }
    break;
  case 3:
    if (tkg3 < 40) {
      total4 = parseInt(tkg3) * 20;
      document.write("<br>" + "總價:" + total4);
    } else if (tkg3 > 40 && tkg3 < 99) {
      total4 = parseInt(tkg3) * 15;
      document.write("<br>" + "總價:" + total4);
    } else if (tkg >= 100) {
      total4 = parseInt(tkg3) * 10;
      document.write("<br>" + "總價:" + total4);
    }
}

//5
// let prize = (Math.random() * 10).toFixed(0);
// console.log(prize);

// let total3 = 0;

// switch (prize) {
//   case "0":
//     if (prize == 0) {
//       alert("抽到0，抽獎結束");
//     }
//   case "1":
//     total3 = 100;
//     break;
//   case "2":
//     total3 = 200;
//     break;
//   case "3":
//     total3 = 300;
//     break;
//   case "4":
//     total3 = 400;
//     break;
//   case "5":
//     total3 = 500;
//     break;
//   case "6":
//     total3 = 600;
//     break;
//   case "7":
//     total3 = 700;
//     break;
//   case "8":
//     total3 = 800;
//     break;
//   case "9":
//     total3 = 900;
//     break;
//   case "10":
//     total3 = 1000;
// }

// document.write("<br>" + "彩球金額" + total3);
//6

let star = "";
for (b = 0; b < 6; b++) {
  star += "*";
  document.write("<br>" + star);
  document.write("<br>");
}

var strNum = "";
for (let i = 1; i <= 6; i++) {
  for (let j = 1; j <= i; j++) {
    strNum += j;
  }
  strNum += "<br>";
}
document.write(strNum);

let strNum2 = 0;
for (let i = 1; i <= 10; i++) {
  strNum2 += i;
  document.write("<br>" + strNum2);
}

function rand(min, max) {
  let radNum = Math.floor(Math.random() * (max - min + 1)) + min;
  //會隨機產生10~20之間的數
  //+1為擃大一個單位
  //+1是為了確保max數也會生成，如果未加+1最大數只會到19
  return radNum;
}
let result1 = rand(3, 10);
console.log(result1);

//BMI換算

let submit = document.querySelector("#sub");

submit.addEventListener("click", () => {
  let cm = document.querySelector("#cm").value;
  let kg = document.querySelector("#kg").value;
  let height = parseFloat(cm) * 0.01;
  let bmi = parseFloat(kg) / (height * height);

  if (bmi < 18.5) {
    alert("過輕");
  } else if (18.5 <= bmi && bmi < 24) {
    alert("正常範圍");
  } else if (24 <= bmi && bmi < 27) {
    alert("過重");
  } else if (27 <= bmi && bmi < 30) {
    alert("小肥");
  } else if (30 <= bmi && bmi < 35) {
    alert("有點肥");
  } else if (bmi >= 35) {
    alert("太肥");
  }
});
