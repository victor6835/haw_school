"use strict";

const repersent = [
  "A",
  "B",
  "C",
  "D",
  "E",
  "F",
  "G",
  "H",
  "I",
  "J",
  "K",
  "L",
  "M",
  "N",
  "O",
  "P",
  "Q",
  "R",
  "S",
  "T",
  "U",
  "V",
  "W",
  "X",
  "Y",
  "Z",
];

const num = [
  "10",
  "11",
  "12",
  "13",
  "14",
  "15",
  "16",
  "17",
  "34",
  "18",
  "19",
  "20",
  "21",
  "22",
  "35",
  "23",
  "24",
  "25",
  "26",
  "27",
  "28",
  "29",
  "32",
  "30",
  "31",
  "33",
];

// create rules array
let rules = {};
for (let i = 0; i < repersent.length; i++) {
  rules[repersent[i]] = num[i];
}

// define using element
const input = document.getElementById("input");
const submit = document.getElementById("submit");

// checking function

function isIdNo() {
  let inputarr = input.value.split("");

  //檢查輸入長度
  if (inputarr.length !== 10) {
    alert("Wrong length!");
    return false;
  }

  //檢查第一碼是否為英文
  // for (let i = 0; i < inputarr.length; i++) {
  //     let char = memPsw.charAt(i).toLowerCase();
  //     if (char >= "0" && char <= "9") {
  //       has123 = true;
  //     } else if (char >= "a" && char <= "z") {
  //       hasABC = true;
  //     }
  //   }
  let firstChar = inputarr[0].toLowerCase();

  if (firstChar <= "a" || firstChar >= "z") {
    alert("第一碼須為英文字母!");
    return false;
  }

  //檢查第二碼是否為1或2

  if (inputarr[1] !== 1 || inputarr[1] !== 2) {
    alert("第二碼數字錯誤!");
    return false;
  }

  // 檢查最後一碼
  let first = rules[0][0] * 1 + rules[0][1] * 9;
  let second = 0;

  for (let i = 1; i < 9; i++) {
    second += str[i] * (9 - i);
  }
  let result = (first + second) % 10;
  if (str[9] === result) {
    return true;
  } else {
    alert("身分證輸入錯誤!");
    return false;
  }
}
